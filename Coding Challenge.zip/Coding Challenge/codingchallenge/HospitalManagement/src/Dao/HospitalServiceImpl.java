package Dao;

import Entity.Appointment;
import Util.DBconnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class HospitalServiceImpl implements HospitalService {
    private List<Appointment> appointments;

    public HospitalServiceImpl() {
        // Initialize the list of appointments
        this.appointments = new ArrayList<>();
    }

    @Override
    public Appointment getAppointmentById(int appointmentId) {
        try (Connection connection = DBconnection.getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM Appointment WHERE appointmentId = ?")) {
            statement.setInt(1, appointmentId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return new Appointment(
                        resultSet.getInt("appointmentId"),
                        resultSet.getInt("patientId"),
                        resultSet.getInt("doctorId"),
                        resultSet.getDate("appointmentDate"),
                        resultSet.getString("description")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Failed to get appointment by ID: " + e.getMessage());
        }
        return null;
    }

    @Override
    public List<Appointment> getAppointmentsForPatient(int patientId) {
        List<Appointment> patientAppointments = new ArrayList<>();
        try (Connection connection = DBconnection.getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM Appointment WHERE patientId = ?")) {
            statement.setInt(1, patientId);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Appointment appointment = new Appointment(
                        resultSet.getInt("appointmentId"),
                        resultSet.getInt("patientId"),
                        resultSet.getInt("doctorId"),
                        resultSet.getDate("appointmentDate"),
                        resultSet.getString("description")
                );
                patientAppointments.add(appointment);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Failed to get appointments for patient: " + e.getMessage());
        }
        return patientAppointments;
    }

    @Override
    public List<Appointment> getAppointmentsForDoctor(int doctorId) {
        List<Appointment> doctorAppointments = new ArrayList<>();
        try (Connection connection = DBconnection.getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM Appointment WHERE doctorId = ?")) {
            statement.setInt(1, doctorId);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Appointment appointment = new Appointment(
                        resultSet.getInt("appointmentId"),
                        resultSet.getInt("patientId"),
                        resultSet.getInt("doctorId"),
                        resultSet.getDate("appointmentDate"),
                        resultSet.getString("description")
                );
                doctorAppointments.add(appointment);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Failed to get appointments for doctor: " + e.getMessage());
        }
        return doctorAppointments;
    }

    @Override
    public boolean scheduleAppointment(Appointment appointment) {
        // Assuming appointmentId is unique
        if (appointment != null && !appointments.contains(appointment)) {
            appointments.add(appointment);
            return true;
        }
        return false;
    }

    @Override
    public boolean updateAppointment(Appointment appointment) {
        String sql = "UPDATE Appointment SET appointmentDate = ?, description = ? WHERE appointmentId = ?";
        Connection connection = null;
        PreparedStatement statement = null;
        try {
            connection = DBconnection.getConnection();
            statement = connection.prepareStatement(sql);
            statement.setDate(1, appointment.getAppointmentDate());
            statement.setString(2, appointment.getDescription());
            statement.setInt(3, appointment.getAppointmentId());

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                // Update the appointment in the in-memory list
                for (int i = 0; i < appointments.size(); i++) {
                    if (appointments.get(i).getAppointmentId() == appointment.getAppointmentId()) {
                        appointments.set(i, appointment);
                        break;
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Failed to update appointment: " + e.getMessage());
        } finally {
            // Close the statement and connection
            try {
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
                System.err.println("Failed to close statement or connection: " + e.getMessage());
            }
        }
        return false;
    }

    @Override
    public boolean cancelAppointment(int appointmentId) {
        try (Connection connection = DBconnection.getConnection();
            PreparedStatement statement = connection.prepareStatement("DELETE FROM Appointment WHERE appointmentId = ?")) {
            statement.setInt(1, appointmentId);

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                // Remove the appointment from the in-memory list
                for (int i = 0; i < appointments.size(); i++) {
                    if (appointments.get(i).getAppointmentId() == appointmentId) {
                        appointments.remove(i);
                        break;
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Failed to cancel appointment: " + e.getMessage());
        }
        return false;
    }
}