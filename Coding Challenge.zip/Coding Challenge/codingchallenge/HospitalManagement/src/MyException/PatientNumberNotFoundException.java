package MyException;


    public class PatientNumberNotFoundException extends Exception {
        private int patientNumber;
    
        public PatientNumberNotFoundException(int patientNumber) {
            super("Patient with number " + patientNumber + " not found.");
            this.patientNumber = patientNumber;
        }
    
        public int getPatientNumber() {
            return patientNumber;
        }
    }